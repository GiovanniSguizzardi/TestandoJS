function cabecalho(autor, programa) {
    console.log("Programa: " + programa);
    console.log("Autor: " + autor);
}

cabecalho("Tobias", "Arrays"); 