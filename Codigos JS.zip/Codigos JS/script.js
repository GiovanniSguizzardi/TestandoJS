//  Função para realizar as operações seguintes
let num1 = 18;
let num2 = 5;

// Métodos da calculadora
let soma = num1 + num2;
let subtrair = num1 - num2;
let multiplicar = num1 * num2;
let dividir = num1 / num2;

// Print dos resultados
console.log("[SOMA] resultado:", soma);
console.log("[SUBTRAÇÃO] resultado:", subtrair);
console.log("[MULTIPLICAÇÃO] resultado:", multiplicar);
console.log("[DIVISÃO] resultado:", dividir);