let a = 10;
let b = 3;

let c = a%b
console.log(c)

let x = "10";
if (a === x) {
    console.log("São iguais")
} else {
    console.log("Não são iguais")
}