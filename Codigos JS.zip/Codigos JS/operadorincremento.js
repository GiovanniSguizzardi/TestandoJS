let a = 10;
let b = 20;

/* 
a++;
++b;
let c = a+b;
*/

let c = a++ + ++b; //A++ roda dps que ++B pois existem sufixos e prefixos em .js
console.log(c)