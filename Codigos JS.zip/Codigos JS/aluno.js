let aluno1 = ["RM551261", "João Silva", "(11) 1111-1111", "joaoficial@gmail.com"]

let aluno2 = {
    rm: 551261,
    nome: "Gabriel Silva",
    telefone: "(19) 1919-9191",
    email: "gabrielbriel@gmail.com"
}

console.log(aluno2)
console.log(aluno2.nome)

let s1 = Symbol("jif1j90191ng0913ng90");
let a;
let b = null;

console.log("A:", a);
console.log("B:", b);

let c = 10;
c = 15;