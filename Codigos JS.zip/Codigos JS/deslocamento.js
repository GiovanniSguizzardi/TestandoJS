let a = 25;
let b = a >> 2;

console.log(b)