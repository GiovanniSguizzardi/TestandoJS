/* Cada numero desse array tem um indice!

             0  1  2  03  4  05  06  07  */
let lista = [3, 5, 7, 11, 3, 17, 19, 23];
let soma_lista = lista[0] + lista[1] + lista[2]
console.log("Soma dos 3 indexes iniciais:" ,soma_lista)

console.log()

let soma = 0;
let i = 0;
while(i < 8) {
    soma = soma + lista[i];
    i = i + 1;
}
console.log("Soma da Lista:", soma)